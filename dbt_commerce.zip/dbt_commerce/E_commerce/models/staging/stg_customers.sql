select *
from raw.e_commerce_customer